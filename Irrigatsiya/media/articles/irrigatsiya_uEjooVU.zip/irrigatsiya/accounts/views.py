# from django.shortcuts import render, redirect
# from .forms import UserRegisterForm
# from .models import Profile
# from django.contrib.auth.models import User
# from django.contrib import messages
# from django.contrib.auth import authenticate, login


# def register(request):
#     if request.method == 'POST':
#         form = UserRegisterForm(request.POST)
#         if form.is_valid():
#             form.save()
#             firstname = form.cleaned_data.get('first_name')
#             lastname = form.cleaned_data.get('last_name')
#             password = form.cleaned_data.get('password1')
#             messages.success(request, 'Account has been created successfully!')
#             user = authenticate(username=firstname, password=password)
#             login(request, user)
#             return redirect('profile')                 
#     else:
#         form = UserRegisterForm()

#     context = {
#         'form':form
#     }
    
#     return render(request, 'register.html', context)

# def profile(request):

#     return render(request, 'profile.html', {})


from django.shortcuts import render, redirect, get_object_or_404
from .forms import (
    UserRegisterForm,
    UserUpdateForm,
    ProfileUpdateForm,
    )
from .models import Profile
from django.views.generic import DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login
from django.contrib.auth.models import User
from django.contrib import messages

# class RegisterView(UserRegisterForm):
#     template_name = "register.html"
#     form_class = UserRegisterForm
#     def form_valid(self, form):
#         form.save()
#         username = form.cleaned_data.get("username")
#         password = form.cleaned_data.get("password1")
#         messages.info(f'Hey {username}, We are glad to see you here!Try our tutorials!')
#         user = authenticate(username=username, password=password)
#         login(request, user)
#         return redirect("courses")

        
def register(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password1")
            messages.info(request, f'Hey {username}, Account has been created!')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect("profile")
    else:
        form = UserRegisterForm()
    context = {
        'form':form
    }
    return render(request, 'register.html', context)

# @login_required
# def profile (request):
    # if request.method=="POST":
    #     u_form = UserUpdateForm( request.POST, instance=request.user)
    #     p_form = ProfileUpdateForm( request.POST, request.FILES,instance=request.user.profile)
    #     if u_form.is_valid() and p_form.is_valid():
    #         u_form.save()
    #         p_form.save()
    #         return redirect('profile')

    # else:
    #     u_form = UserUpdateForm(instance=request.user)
    #     p_form = ProfileUpdateForm(instance=request.user.profile)
    # context = {
    #     'u_form':u_form,
    #     'p_form':p_form,
    # }
    # return render(request, "profile.html", context)

class Profile(LoginRequiredMixin, DetailView):    
    template_name = 'users/profile.html'    
    #queryset = User.objects.all()    
    
    # def get_object(self):        
    #     id_ = self.kwargs.get("username")        
    #     user = get_object_or_404(Profile, username=id_)     # User, username=id_   
    #     return user

    def get_context_data(self, *args, **kwargs):
        super(Profile, self).get_context_data(*args, **kwargs)
        context = {
            'user': self.request.user
        }
        return context

@login_required
def profile (request):
    context = {
            'user': request.user
        }
    return render(request, "profile.html", context)