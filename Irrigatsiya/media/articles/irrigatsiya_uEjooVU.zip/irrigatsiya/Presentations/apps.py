from django.apps import AppConfig


class PresentationsConfig(AppConfig):
    name = 'Presentations'
